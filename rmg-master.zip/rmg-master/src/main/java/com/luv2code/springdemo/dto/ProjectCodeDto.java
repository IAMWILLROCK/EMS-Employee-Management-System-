package com.luv2code.springdemo.dto;

public class ProjectCodeDto {

	String projectCode;
	
	public ProjectCodeDto()
	{
		
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	
}
