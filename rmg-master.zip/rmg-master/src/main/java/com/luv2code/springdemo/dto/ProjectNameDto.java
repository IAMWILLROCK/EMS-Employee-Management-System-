package com.luv2code.springdemo.dto;

public class ProjectNameDto {
private String projectCode;
private String projectName;

public ProjectNameDto()
{
	
}

public String getProjectCode() {
	return projectCode;
}

public void setProjectCode(String projectCode) {
	this.projectCode = projectCode;
}

public String getProjectName() {
	return projectName;
}

public void setProjectName(String projectName) {
	this.projectName = projectName;
}



}
