package com.luv2code.springdemo.dao;

import com.luv2code.springdemo.entity.AllocationPyramid;

public interface AllocationPyramidDAO {

	public AllocationPyramid getPyramid(String grade);

}
