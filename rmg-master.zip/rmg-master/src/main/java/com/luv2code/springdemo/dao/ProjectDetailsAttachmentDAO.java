package com.luv2code.springdemo.dao;


import com.luv2code.springdemo.entity.ProjectDetailsAttachment;

public interface ProjectDetailsAttachmentDAO {

  

	public void saveAttachment(ProjectDetailsAttachment projectDetailsAttachment);

}
