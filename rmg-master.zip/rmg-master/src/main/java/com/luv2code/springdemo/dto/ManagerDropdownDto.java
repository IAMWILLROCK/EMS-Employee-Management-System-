package com.luv2code.springdemo.dto;

public class ManagerDropdownDto {
	
	private String managerId;
	
	private String managerName;
	
	public ManagerDropdownDto()
	{
		
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	
	

}
