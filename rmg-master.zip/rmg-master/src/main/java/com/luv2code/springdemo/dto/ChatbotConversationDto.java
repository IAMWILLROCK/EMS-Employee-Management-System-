package com.luv2code.springdemo.dto;

public class ChatbotConversationDto {

	
}
