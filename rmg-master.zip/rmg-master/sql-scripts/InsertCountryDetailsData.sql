
INSERT INTO country (country_code, country, region_id)
VALUES ('MYS', 'Malaysia', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('THA', 'Thailand', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('SGP', 'Singapore', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('IDN', 'Indonesia', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('MMR', 'Burma', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('PHL', 'Philippines', 'SEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('CHN', 'China', 'APAC');
INSERT INTO country (country_code, country, region_id)
VALUES ('JPN', 'Japan', 'APAC');
INSERT INTO country (country_code, country, region_id)
VALUES ('AUS', 'Australia', 'ANZ');
INSERT INTO country (country_code, country, region_id)
VALUES ('NZL', 'New Zealand', 'ANZ');
INSERT INTO country (country_code, country, region_id)
VALUES ('DEU', 'Germany', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('GBR', 'UK', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('ESP', 'Spain', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('FRA', 'France', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('ITA', 'Italy', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('RUS', 'Russia', 'EMEA');
INSERT INTO country (country_code, country, region_id)
VALUES ('USA', 'USA', 'NA');
INSERT INTO country (country_code, country, region_id)
VALUES ('CAN', 'Canada', 'NA');
INSERT INTO country (country_code, country, region_id)
VALUES ('MEX', 'Mexico', 'NA');

insert into "USR_88I4FERW280TXGU6ZMSPFY860"."COUNTRY" values('IND','India','India')