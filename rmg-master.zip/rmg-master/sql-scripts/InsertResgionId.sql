INSERT INTO `region` VALUES 
				('India', 'India'),
                ('SEA', 'South East Asia'),
                ('APAC','Asia Pacific'),
                ('ANZ','Australia'),
                ('EMEA','Europe, the Middle East and Africa '),
                ('NA','North America')