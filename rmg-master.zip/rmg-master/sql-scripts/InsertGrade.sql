insert into "GRADE" 
values('G1.1','G1','G1.1');
insert into "GRADE" 
values('G1.2','G1','G1.2');
insert into "GRADE" 
values('G1.3','G1','G1.3');
insert into "GRADE" 
values('G2.1','G2','G2.1');
insert into "GRADE" 
values('G2.2','G2','G2.2');
insert into "GRADE" 
values('G2.3','G2','G2.3');
insert into "GRADE" 
values('G3.1','G3','G3.1');
insert into "GRADE" 
values('G3.2','G3','G3.2');
insert into "GRADE" 
values('G3.3','G3','G3.3');