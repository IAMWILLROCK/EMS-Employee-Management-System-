insert into functional_domain 
values('SAP HCM','SAP HCM');
insert into functional_domain 
values('SAP MM','SAP MM');
insert into functional_domain 
values('SAP FICO','SAP FICO');
insert into functional_domain 
values('SAP SD','SAP SD');
insert into functional_domain 
values('SAP PP','SAP PP');
insert into functional_domain
values('SAP FSCM','SAP FSCM');
insert into functional_domain 
values('AI/ML','AI/ML');
