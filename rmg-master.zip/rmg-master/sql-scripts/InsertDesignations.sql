insert into DESIGNATION values('Consultant-Technology','Consultant-Technology');
insert into DESIGNATION values('Associate Consultant-Technology','Associate Consultant-Technology');
insert into DESIGNATION values('Senior Consultant-Technology','Senior Consultant-Technology');
insert into DESIGNATION values('Lead-Functional','Lead-Functional');
insert into DESIGNATION values('Senior Analyst-Quality Assurance','Senior Analyst-Quality Assurance');
insert into DESIGNATION values('Manager-Delivery','Manager-Delivery');
insert into DESIGNATION values('Project Manager','Project Manager');



Consultant-Technology

Associate Consultant-Technology

Senior Consultant-Technology

Lead-Functional

Senior Analyst-Quality Assurance


Manager-Delivery

