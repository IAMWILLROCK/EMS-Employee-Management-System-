insert into allocation_pyramid 
values('G1.1','20');
insert into allocation_pyramid 
values('G1.2','35');
insert into allocation_pyramid 
values('G1.3','20');
insert into allocation_pyramid 
values('G2.1','15');
insert into allocation_pyramid 
values('G2.2','10');
insert into allocation_pyramid 
values('G2.3','10');
insert into allocation_pyramid 
values('G3.1','10');
insert into allocation_pyramid 
values('G3.2','10');
insert into allocation_pyramid 
values('G3.3','10');