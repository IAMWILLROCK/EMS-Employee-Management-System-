INSERT INTO department
VALUES ("IT", "IT");
INSERT INTO department
VALUES ("Sales", "Sales");
INSERT INTO department
VALUES ("Marketing", "Marketing");
INSERT INTO department
VALUES ("Human Resource Management", "Human Resource Managemen");
INSERT INTO department
VALUES ("Production", "Production");
INSERT INTO department
VALUES ("Accounts & Finance", "Accounts & Finance");
INSERT INTO department
VALUES ("R&D", "R&D");
INSERT INTO department
VALUES ("Purchasing", "Purchasing");


INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('IT', 'IT');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Sales', 'Sales');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Marketing', 'Marketing');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Human Resource Management', 'Human Resource Managemen');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Production', 'Production');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Accounts & Finance', 'Accounts & Finance');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('R&D', 'R&D');
INSERT INTO "USR_6YATU92LYYEXMOVKVMI297HE5"."DEPARTMENT"
VALUES ('Purchasing', 'Purchasing');
